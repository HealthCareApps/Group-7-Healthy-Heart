package edu.nlandi2013fau.arduino2;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by Nicholas on 4/6/2016.
 */
public class Results extends AppCompatActivity {

    private String filecontents;
    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        lv = (ListView) findViewById(R.id.listView);
        readResults();
        displayResults(parseResults());
    }

    public void displayResults(ArrayList<String> thing){
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                thing
        );
        lv.setAdapter(arrayAdapter);
    }

    public void readResults(){
        Context context = getApplicationContext();
        File file = new File(context.getFilesDir(), Reading.FILENAME);
        FileInputStream inputStream = null;
        String line = null;
        StringBuilder sb = null;

        try{
            inputStream = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            sb = new StringBuilder();
            while((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();
            inputStream.close();
        }catch (Exception e){
            e.printStackTrace();
        }

        if(sb != null) {
            filecontents = sb.toString();
        }
        else{
           filecontents = "You Have No Results!";
        }
    }

    public ArrayList<String> parseResults(){
        ArrayList<String> resultArray = new ArrayList<>();
        int stringSize = filecontents.length();
        int counter = 0;
        int holder = 0;

        while(counter < stringSize){
            if(filecontents.charAt(counter) == '|'){
                resultArray.add(filecontents.substring(holder,counter));
                holder = counter + 1;
                counter++;
            }
            counter++;
        }
        return resultArray;
    }


}
