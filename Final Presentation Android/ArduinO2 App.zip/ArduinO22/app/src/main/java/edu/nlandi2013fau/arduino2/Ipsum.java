package edu.nlandi2013fau.arduino2;

/**
 * Created by Nicholas on 4/6/2016.
 */
public class Ipsum {
    static String[] Headlines = {
            "Heart Failure",
            "Symptoms",
            "Causes",
            "Home Care",
            "Call Your Health-care Provider If",
            "Seek Immediate Medical Care If",
            "How to Use ArduinO2",
            "What Your Results Mean"
    };

    static String[] Articles = {
            Headlines[0] + "\n\n" + "\u2022This means your heart does not pump blood efficiently for your body to work well." + "\n\n" + "\u2022Usually a long-term condition",
            Headlines[1] + "\n\n" + "\u2022Shortness of breath with mild exercise or while at rest." + "\n\n" + "\u2022Rapid, fast breathing" + "\n\n" + "\u2022Fast heart rate" + "\n\n" + "\u2022A persistent cough." + "\n\n" +"\u2022Abnormal swelling in the feet and legs."
                    + "\n" + "\u2022Unexplained sudden weight gain." + "\n\n" + "\u2022Fatigue and loss of energy." + "\n\n" + "\u2022Feeling lightheaded or close to fainting." + "\n\n" + "\u2022Chest or abdominal pain.",
            Headlines[2] + "\n\n" + "\u2022Coronary artery disease." + "\n\n" + "\u2022High blood pressure" + "\n\n" + "\u2022Diabetes"  + "\n\n" + "\u2022Heart attacks." + "\n\n" + "\u2022Abnormal heart valves."
                    + "\n\n" + "\u2022Lung disease.",
            Headlines[3] + "\n\n" + "\u2022Take your heart medications as told by your doctor" + "\n\n" + "\u2022Limit fluids as told by your doctor" + "\n\n" + "\u2022Weigh yourself every morning, and write it down" + "\n\n" + "\u2022Take your blood pressure and write it down" + "\n\n" + "\u2022Check your pulse" +
                    "\n\n" + "\u2022Rest when tired" + "\n\n" + "\u2022Avoid caffeinated drinks" + "\n\n" + "\u2022Reduce stress and anxiety",
            Headlines[4] + "\n\n"  + "\u2022You gain 3lbs or more in 1 day" + "\n\n" + "\u2022You are more short of breath than usual" + "\n\n" + "\u2022You tire easily" + "\n\n" + "\u2022You cannot sleep because it is hard to breath" +
                    "\n\n" + "\u2022You feel like your heart is beating fast (palpitations)",
            Headlines[5] + "\n\n" + "\u2022You develop increased breathing, shortness of breath, severe cough or are coughing up blood.\n\n\u2022You have severe chest or abdominal pain, or unusual heart palpitations.\n\n\u2022You have bluish color to your finger or toe nail beds\n\n" +
                    "\u2022There is change in mental status, such as becoming less alert or not being able to focus\n\n" +
                    "\u2022You develop weakness or numbness in your face or on one side of the body.\n\n" +
                    "\u2022You faint.",
            Headlines[6] + "\n\n" + "\u2022Place the pulse oximeter on your finger and press the grey button. Allow the sensor time to calibrate\n\n" + "\u2022Press the \"Take a reading\" button and select the proper bluetooth device to connect to the pulse oximeter\n\n" +
                    "\u2022Once you are connected you can press the \"Take Reading\" button that appears and ArduinO2 will take your reading, this may take up to ten seconds\n\n" +
                    "\u2022After your reading has been taken you may take more readings or return to the main screen. All of your past results are viewable in the \"View Your Past Results\" section.",
            Headlines[7] + "\n\n\u2022The normal SpO2 level should be between 94 and 99%.\n\n\u2022The normal level for heart rate depends on your age, gender, and level of activity but generally should range between 60 and 100 bpm."
    };
}
