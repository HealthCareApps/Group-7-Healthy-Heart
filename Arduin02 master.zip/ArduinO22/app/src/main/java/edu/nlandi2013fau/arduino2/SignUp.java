package edu.nlandi2013fau.arduino2;



import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nicholas on 3/18/2016.
 */
public class SignUp extends Activity {

    private static final String url = "jdbc:mysql://us-cdbr-iron-east-03.cleardb.net/ad_1273066cc954e6e?user=b1d9011fe0512a&password=c09ad412";
    private static final String user = "b1d9011fe0512a";
    private static final String pass = "c09ad412";
    private userPush mAuthTask = null;

    private EditText mNameView;
    private EditText mEmailView;
    private EditText mPasswordView;
    private View mSignFormView;
    private View mProgressView;


    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        // Set up the login form.
        setContentView(R.layout.activity_sign_up);

        mNameView = (EditText) findViewById(R.id.sign_up_name);
        mEmailView = (EditText) findViewById(R.id.sign_up_email);
        mPasswordView = (EditText) findViewById(R.id.sign_up_password);

        Button mSignUp = (Button) findViewById(R.id.sign_up_button);
        mSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pushAccount();

            }
        });

        mSignFormView = findViewById(R.id.sign_form);
        mProgressView = findViewById(R.id.sign_progress);
   }

    public void pushAccount(){
        if (mAuthTask!=null)
        {
            return;
        }

        mNameView.setError(null);
        mEmailView.setError(null);
        mPasswordView.setError(null);

        String name = mNameView.getText().toString();
        String email = mEmailView.getText().toString();
        String password = mPasswordView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password, if the user entered one.
        if (TextUtils.isEmpty(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid email address.
        if (TextUtils.isEmpty(email)) {
            mEmailView.setError(getString(R.string.error_field_required));
            focusView = mEmailView;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            showProgress(true);
            mAuthTask = new userPush(name, email, password,this);
            Toast toast = new Toast(getApplicationContext());
            toast.setText("Your account has been created!");
            toast.setDuration(Toast.LENGTH_LONG);
            toast.show();
            mAuthTask.execute((Void) null);
        }
    }

    public void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mSignFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mSignFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mSignFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mSignFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }



    public class userPush extends AsyncTask<Void, Void, Boolean> {

        private final String mName;
        private final String mEmail;
        private final String mPassword;
        private final List<String> Credentials;
        private String result;
        ProgressDialog progressDialog;
        private Activity activity;



        userPush(String name, String email, String password, Activity activity){
            mName = name;
            mEmail = email;
            mPassword = password;
            Credentials = new ArrayList<>();
            this.activity = activity;
        }



        @Override
        protected void onPreExecute(){
            progressDialog = new ProgressDialog(activity);
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.


            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection con = DriverManager.getConnection(url, user, pass);
                System.out.println("Databasection success");

                result = "Database connection success\n";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("insert into users (ID, email, password, name) values (NULL," + mEmail + "," + mPassword + " ," + mName + ");");
                ResultSetMetaData rsmd = rs.getMetaData();

                con.close();
            }
            catch(Exception e) {
                e.printStackTrace();
            }



            return false;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mAuthTask = null;
            showProgress(false);

            if (success) {
                finish();
                Intent myIntent = new Intent(SignUp.this,MainMenu.class);
                SignUp.this.startActivity(myIntent);
            } else {
                mPasswordView.setError(getString(R.string.error_incorrect_password));
                mPasswordView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mAuthTask = null;
            showProgress(false);
        }
    }
}
