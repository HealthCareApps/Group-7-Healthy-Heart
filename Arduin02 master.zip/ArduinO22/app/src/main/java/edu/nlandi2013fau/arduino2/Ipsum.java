package edu.nlandi2013fau.arduino2;

/**
 * Created by Nicholas on 4/6/2016.
 */
public class Ipsum {
    static String[] Headlines = {
            "Heart Failure",
            "Symptoms",
            "Causes",
            "Home Care",
            "Call your doctor if",
            "Seek immediate medical care if"

    };

    static String[] Articles = {
            Headlines[0] + "\n\n" + R.string.heart_point_1 + "\n" + R.string.heart_point_2,
            Headlines[1] + "\n\n" + R.string.symptom1 + "\n" + R.string.symptom2 + "\n" + R.string.symptom3 + "\n" + R.string.symptom4 + "\n" + R.string.symptom5
                    + "\n" + R.string.symptom6 + "\n" + R.string.symptom7 + "\n" + R.string.symptom8 + "\n" + R.string.symptom9,
            Headlines[2] + "\n\n" + R.string.cause1 + "\n" + R.string.cause2 + "\n" + R.string.cause3  + "\n" + R.string.cause4 + "\n" + R.string.cause5
                    + "\n" + R.string.cause6,
            Headlines[3] + "\n\n" + R.string.care1 + "\n" + R.string.care2 + "\n" + R.string.care3 + "\n" + R.string.care4 + "\n" + R.string.care5 +
                    "\n" + R.string.care6 + "\n" + R.string.care7 + "\n" + R.string.care8,
            Headlines[4] + "\n\n"  + R.string.doctor1 + "\n" + R.string.doctor2 + "\n" + R.string.doctor3 + "\n" + R.string.doctor4 +
                    "\n" + R.string.doctor5,
            Headlines[5] + "\n\n"
    };
}
