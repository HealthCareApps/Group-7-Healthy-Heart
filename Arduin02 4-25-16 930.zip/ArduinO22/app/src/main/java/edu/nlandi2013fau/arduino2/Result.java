package edu.nlandi2013fau.arduino2;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Nicholas on 4/13/2016.
 */
public class Result {

    public String resstr;

    public Result(String bpm, String SpO2){
        SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy hh:mm");
        String format = s.format(new Date());
        resstr = (format + "|" + bpm + "|" + SpO2 + "|" + "\n");
    }


}
