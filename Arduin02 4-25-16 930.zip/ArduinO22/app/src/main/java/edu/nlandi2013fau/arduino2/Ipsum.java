package edu.nlandi2013fau.arduino2;

/**
 * Created by Nicholas on 4/6/2016.
 */
public class Ipsum {
    static String[] Headlines = {
            "Heart Failure",
            "Symptoms",
            "Causes",
            "Home Care",
            "Call Your Health-care Provider If",
            "Seek Immediate Medical Care If"
    };

    static String[] Articles = {
            Headlines[0] + "\n\n" + "\u2022This means your heart does not pump blood efficiently for your body to work well." + "\n" + "\u2022Usually a long-term condition",
            Headlines[1] + "\n\n" + "\u2022Shortness of breath with mild exercise or while at rest." + "\n" + "\u2022Rapid, fast breathing" + "\n" + "\u2022Fast heart rate" + "\n" + "\u2022A persistent cough." + "\n" +"\u2022Abnormal swelling in the feet and legs."
                    + "\n" + "\u2022Unexplained sudden weight gain." + "\n" + "\u2022Fatigue and loss of energy." + "\n" + "\u2022Feeling lightheaded or close to fainting." + "\n" + "\u2022Chest or abdominal pain.",
            Headlines[2] + "\n\n" + "\u2022Coronary artery disease." + "\n" + "\u2022High blood pressure" + "\n" + "\u2022Diabetes"  + "\n" + "\u2022Heart attacks." + "\n" + "\u2022Abnormal heart valves."
                    + "\n" + "\u2022Lung disease.",
            Headlines[3] + "\n\n" + "u2022Take your heart medications as told by your doctor" + "\n" + "\u2022Limit fluids as told by your doctor" + "\n" + "\u2022Weigh yourself every morning, and write it down" + "\n" + "\u2022Take your blood pressure and write it down" + "\n" + "\u2022Check your pulse" +
                    "\n" + "\u2022Rest when tired" + "\n" + "\u2022Avoid caffeinated drinks" + "\n" + "\u2022Reduce stress and anxiety",
            Headlines[4] + "\n\n"  + "\u2022You gain 3lbs or more in 1 day" + "\n" + "\u2022You are more short of breath than usual" + "\n" + "\u2022You tire easily" + "\n" + "\u2022You cannot sleep because it is hard to breath" +
                    "\n" + "\u2022You feel like your heart is beating fast (palpitations)",
            Headlines[5] + "\n\n"
    };
}
